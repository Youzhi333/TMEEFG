#ifndef POKERGAMESFIVEPLAYER_HPP_
#define POKERGAMESFIVEPLAYER_HPP_
#include "cardfiveplayer.hpp"
#include "pokertreesfiveplayer.hpp"

namespace r5{

float kuhn_eval(vector<Card> hc, vector<Card> board);
GameRules half_street_kuhn_rules(int playerNumber, int adversaryPlayer, int rankN);
GameTree half_street_kuhn_gametree(int playerNumber, int adversaryPlayer, int rankN);
PublicTree half_street_kuhn_publictree(int playerNumber, int adversaryPlayer, int rankN);
GameRules kuhn_rules(int playerNumber, int adversaryPlayer, int rankN);
GameTree kuhn_gametree(int playerNumber, int adversaryPlayer, int rankN);
PublicTree kuhn_publictree(int playerNumber, int adversaryPlayer, int rankN);
string leduc_format(int player, vector<Card> holecards, vector<Card> board, string bet_history);
float leduc_eval(vector<Card> hc, vector<Card> board);
GameRules leduc_rules(int playerNumber, int adversaryPlayer, int rankN);
GameRules leduc_rules2(int playerNumber, int adversaryPlayer, int rankN);
GameRules leduc_rulessmall(int playerNumber, int adversaryPlayer);
GameTree leduc_gametree(int playerNumber, int adversaryPlayer, int rankN);
//GameTree leduc_gametree3(int playerNumber, int adversaryPlayer, int rankN);
PublicTree leduc_publictree(int playerNumber, int adversaryPlayer, int rankN);
string royal_format(int player, vector<Card> holecards, vector<Card> board, string bet_history);
float royal_eval(vector<Card> hc, vector<Card> board);
GameRules royal_rules(int playerNumber, int adversaryPlayer, int rankN);
GameTree royal_gametree(int playerNumber, int adversaryPlayer, int rankN);
PublicTree royal_publictree(int playerNumber, int adversaryPlayer, int rankN);

}

#endif
