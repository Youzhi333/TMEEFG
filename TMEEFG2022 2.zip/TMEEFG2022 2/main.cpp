///Algorithm CNLP in TMEEFG IJCAI2022: Cited: Youzhi Zhang, Bo An, V.S. Subrahmanian. Correlation-based algorithm for team-maxmin equilibrium in multiplayer extensive-form games. Proceedings of the 31st International Joint Conference on Artificial Intelligence (IJCAI 2022)
//  Requirement:
//1. Gurobi latest version (at least 9.1)
//2. Eigen library: https://eigen.tuxfamily.org/index.php?title=Main_Page
//
//The game library is extended from the two-player game library: https://github.com/achao2013/cppcfr
//
//Parameters: change PLAYERNUMBER/rankN for setting the number of players/ranks
//Change GameRules/GameTree to set Kuhn or Leduc game
//
// Created by Youzhi Zhang on 6/1/2021.

#include "cardfiveplayer.hpp"
#include "pokerstrategyfiveplayer.hpp"
#include "pokergamesfiveplayer.hpp"
 

#include <cassert>
#include "gurobi_c++.h"
#include <iostream>
#include <string>
#include <cstring>
#include <vector>
#include <map>
#include <fstream>
#include <sstream>
#include <math.h>
#include <list>
#include <set>
#include <numeric>
#include <queue>
#include <stdexcept>
#include <.../Eigen/Sparse>
#include <random>
using namespace std;



namespace r5{

typedef Eigen::SparseMatrix<float> SpMat;

#define PLAYERNUMBER 3 //
int player = PLAYERNUMBER - 1;
int rankN =3;
 
 
vector<map<vector<int>, int>> termToVarialbe(PLAYERNUMBER - 2);
vector<map<int, vector<int>>> variableToTerm(PLAYERNUMBER - 2);
vector<map<vector<int>, int>> multitermToVarialbe(PLAYERNUMBER - 2);
vector<map<int, vector<int>>> multivariableToTerm(PLAYERNUMBER - 2);
vector<std::set<int>> variableRelaxed;
 
vector<vector<int>> blTermPlayer(PLAYERNUMBER - 2);

vector<int> allTeamPlayers;
 
vector<vector<vector<int>>> bilinearT(PLAYERNUMBER - 2);
vector<map<string, int>> sequenceToVarialbe(PLAYERNUMBER);
vector<map<string, int>> informationSetToVarialbe(PLAYERNUMBER);
vector<map<int, vector<int>>> terminalSeq2ParentSeq(PLAYERNUMBER);
 

 
 
  
void TMEinEFGMatrix(){
    std::cout << "Testing Strategy"<< "playerN\t" << PLAYERNUMBER << "\t adversary\t" << player << "\t rankN\t" << rankN  << std::endl;//std::cout << "Testing Strategy" << std::endl;
 
    //GameRules rules = r5::kuhn_rules(PLAYERNUMBER, player, rankN);
    //GameTree tree = r5::kuhn_gametree(PLAYERNUMBER, player, rankN);
    GameRules rules = r5::leduc_rules(PLAYERNUMBER, player, rankN);
    GameTree tree = r5::leduc_gametree(PLAYERNUMBER, player, rankN);

    std::cout << "information set size" <<" "<<tree.information_sets[0].size()<<" "<<tree.information_sets[1].size()<< std::endl;
    std::cout << "adversary size" <<" "<<tree.sequencesAll[player].size()<< std::endl;
     


    vector<std::set<vector<int>>> multilinearterms(tree.rules.players - 2);

    for (int p = 0; p < PLAYERNUMBER; p++) {
        if (p != player) {
            allTeamPlayers.push_back(p);
        }
    }

   
    
 
    for (int p = 0; p < tree.rules.players; p++) {
         
        int i = 0;
       
        for (auto& seq : tree.sequencesAll[p]) {
 
            sequenceToVarialbe[p][seq] = i;
 
            i++;
        }

        i = 0;
        for (auto& k : tree.information_sets[p]) {
            informationSetToVarialbe[p][k.first] = i;
            i++;
        }

    }
    

 
 
    for (auto& SQT : tree.sequence_terminal[player]) {
 
        for (auto& nod : SQT.second) {
            vector<int> variableIndex;
            for (auto&p : allTeamPlayers) {
                std::set<string>::iterator itp = tree.sequencesAll[p].find(nod->subsequence[p]);
                variableIndex.push_back(distance(tree.sequencesAll[p].begin(), itp));
            }

            for (int i = 0; i < multilinearterms.size(); i++) {
                vector<int> variableIndexSub;
                for (int p = 0 + i; p < allTeamPlayers.size(); p++) {
                    variableIndexSub.push_back(variableIndex[p]);
                }
                multilinearterms[i].insert(variableIndexSub);
            }
            for (int p = 0; p < variableRelaxed.size(); p++) {
                variableRelaxed[p].insert(variableIndex[p]);
            }

        }
    }
    std::cout << "termsN: " << multilinearterms[0].size() << std::endl;
 
    int bN = 0;
    for (int i = 0; i < multilinearterms.size(); i++) {
        bN += multilinearterms[i].size();
    }
    std::cout << "bilinear terms N: " << bN << std::endl;
    
 
    for (int i = 0; i < blTermPlayer.size(); i++) {
        for (int p = 0 + i; p < allTeamPlayers.size(); p++) {
            blTermPlayer[i].push_back(allTeamPlayers[p]);
        }
 
    }

    int bli = 0;
    for (auto& bl : multilinearterms[multilinearterms.size() - 1]) {
 
        for (int p = 0; p < blTermPlayer[blTermPlayer.size() - 1].size(); p++) {
            std::set<string>::iterator itp = tree.sequencesAll[blTermPlayer[blTermPlayer.size() - 1][p]].begin();
            for (int i = 1; i <= bl[p]; i++) {
                itp++;
            }
             
        }
        
        termToVarialbe[multilinearterms.size() - 1][bl] = bli;
        multitermToVarialbe[multilinearterms.size() - 1][bl] = bli;
        variableToTerm[multilinearterms.size() - 1][bli] = bl;
        multivariableToTerm[multilinearterms.size() - 1][bli] = bl;
        bilinearT[multilinearterms.size() - 1].push_back(bl);
        bli++;
    }

    for (int index = multilinearterms.size() - 2; index >= 0; index--) {
        int bli = 0;
        for (auto& bl : multilinearterms[index]) {
 
            for (int p = 0; p < blTermPlayer[index].size(); p++) {
                std::set<string>::iterator itp = tree.sequencesAll[blTermPlayer[index][p]].begin();
                for (int i = 1; i <= bl[p]; i++) {
                    itp++;
                }
                 
            }

            
            vector<int> subTerm;
            for (int p = 1; p < blTermPlayer[index].size(); p++) {
                subTerm.push_back(bl[p]);
            }

            vector<int> newTerm{ bl[0],multitermToVarialbe[index + 1][subTerm] };
             

            termToVarialbe[index][newTerm] = bli;
            multitermToVarialbe[index][bl] = bli;
            variableToTerm[index][bli] = newTerm;
            multivariableToTerm[index][bli] = bl;
            bilinearT[index].push_back(newTerm);
            bli++;
        }

    }

    GRBEnv env = GRBEnv();

    GRBModel modelEQ = GRBModel(env);
    GRBVar **rSQ = new GRBVar*[tree.rules.players];
    
 
    for (int p = 0; p < tree.rules.players; p++) {
        rSQ[p] = new GRBVar[tree.sequencesAll[p].size()];
         
        std::set<string>::iterator it0 = tree.sequencesAll[p].begin();
        for (int i = 0; i < tree.sequencesAll[p].size(); i++) {
            string seq = *it0;
            
            rSQ[p][i] = modelEQ.addVar(0.0, 1.0, 0.0, GRB_CONTINUOUS,seq);

            it0++;

        }
        modelEQ.addConstr(rSQ[p][0] - 1==0);
        
        
        
      
        for (auto& k : tree.information_sets[p]) {
            
            string seq = k.second[0]->subsequence[p];// tree.information_sets[p][i].first
          
            std::set<string>::iterator it;
            
            GRBLinExpr linexpr;
 
            string seq1 = k.first;
            if (std::static_pointer_cast<ActionNode>(k.second[0])->fold_action.get()) {
 
                it = tree.sequencesAll[p].find(seq1 + 'f');
                linexpr += rSQ[p][distance(tree.sequencesAll[p].begin(), it)];
                 
            }
          
            if (std::static_pointer_cast<ActionNode>(k.second[0])->call_action.get()) {
                
                it = tree.sequencesAll[p].find(seq1 + 'c');
                
                linexpr += rSQ[p][distance(tree.sequencesAll[p].begin(), it)];
                
            }
            
            if (std::static_pointer_cast<ActionNode>(k.second[0])->raise_action.get()) {
                
                it = tree.sequencesAll[p].find(seq1 + 'r');
                
                linexpr += rSQ[p][distance(tree.sequencesAll[p].begin(), it)];
                 

            }
 
            it = tree.sequencesAll[p].find(seq);
            
            
            modelEQ.addConstr(rSQ[p][distance(tree.sequencesAll[p].begin(), it)]-linexpr==0);
             
        }
 
        

    }
 
    float maxU = -100;
    float minU = 100;

    float chanceMaxU = -100;
    float chanceMinU = 100;
    
    for (auto& seq : tree.sequencesAll[player]) {
 
        map<string, std::vector<shared_ptr<Node> >>::iterator  itSQT;
        itSQT = tree.sequence_terminal[player].find(seq);



        if (itSQT != tree.sequence_terminal[player].end()) {
 
            for (auto& nod : itSQT->second) {
                vector<int> variableIndex;
                for (auto&p : allTeamPlayers) {
                    std::set<string>::iterator itp = tree.sequencesAll[p].find(nod->subsequence[p]);
                    variableIndex.push_back(distance(tree.sequencesAll[p].begin(), itp));
                }
 
                
                if (-std::static_pointer_cast<TerminalNode>(nod)->payoffs_g[player] > maxU) {
                    maxU = -std::static_pointer_cast<TerminalNode>(nod)->payoffs_g[player];
                }
                if (-std::static_pointer_cast<TerminalNode>(nod)->payoffs_g[player] < minU) {
                    minU = -std::static_pointer_cast<TerminalNode>(nod)->payoffs_g[player];
                }

                if ((-std::static_pointer_cast<TerminalNode>(nod)->payoffs_g[player])*(std::static_pointer_cast<TerminalNode>(nod)->reachprobility) > chanceMaxU) {
                    chanceMaxU = (-std::static_pointer_cast<TerminalNode>(nod)->payoffs_g[player])*(std::static_pointer_cast<TerminalNode>(nod)->reachprobility);
                }
                if ((-std::static_pointer_cast<TerminalNode>(nod)->payoffs_g[player])*(std::static_pointer_cast<TerminalNode>(nod)->reachprobility) < chanceMinU) {
                    chanceMinU = (-std::static_pointer_cast<TerminalNode>(nod)->payoffs_g[player])*(std::static_pointer_cast<TerminalNode>(nod)->reachprobility);
                }

            }
        }
    }
    
    std::chrono::time_point<std::chrono::system_clock> start, end;
    start = std::chrono::system_clock::now();

    SpMat payoffMatrix(multilinearterms[0].size(),tree.sequencesAll[player].size());
    typedef Eigen::Triplet<float> T;
    std::vector<T> tripletList;
    int seqIndex = 0;
    
    for (auto& seq : tree.sequencesAll[player]) {
        vector<float> aRowPayoff(multilinearterms[0].size(),0);
        //std::cout<<aRowPayoff[0]<<std::endl;
        
        
        map<string, std::vector<shared_ptr<Node> >>::iterator  itSQT;
        itSQT = tree.sequence_terminal[player].find(seq);



        if (itSQT != tree.sequence_terminal[player].end()) {
           // std::cout << seq << std::endl;
            for (auto& nod : itSQT->second) {
                vector<int> variableIndex;
                for (auto&p : allTeamPlayers) {
                    std::set<string>::iterator itp = tree.sequencesAll[p].find(nod->subsequence[p]);
                    variableIndex.push_back(distance(tree.sequencesAll[p].begin(), itp));
                }
                int bli = multitermToVarialbe[0][variableIndex];
                float payoff = (-std::static_pointer_cast<TerminalNode>(nod)->payoffs_g[player])*(std::static_pointer_cast<TerminalNode>(nod)->reachprobility);
                aRowPayoff[bli] = aRowPayoff[bli] + payoff;

 
//
//
            }

        }
        
        for(int i = 0; i < aRowPayoff.size(); i++){
            if(abs(aRowPayoff[i]) > 1e-7){
                tripletList.push_back(T(i,seqIndex,aRowPayoff[i]));
            }
        }
        
        seqIndex++;
        
        
    }
    payoffMatrix.setFromTriplets(tripletList.begin(), tripletList.end());
 
    
   

 
    
    map<int, vector<int>> termToSeq;
    std::set<std::vector<int>> relations;
 
 
    map<vector<int>, int> termToVariableS;
    vector<vector<int>> bilinearTS;
    for (auto &blT : multilinearterms[0]) {
        bilinearTS.push_back(blT);
        termToVariableS[blT] = bilinearTS.size() - 1;
    }
    
    vector<int> blT;
 
    for (int p = 0; p < allTeamPlayers.size(); p++) {
        blT.push_back(sequenceToVarialbe[allTeamPlayers[p]]["/"]);
 
    }
    bilinearTS.push_back(blT);
    termToVariableS[blT] = bilinearTS.size() - 1;

    for (auto &p : allTeamPlayers) {
        for (auto& inf : tree.information_sets[p]) {
            for (auto &nod : inf.second) {
                vector<int> blT;
                for (auto &pp : allTeamPlayers) {
                    blT.push_back(sequenceToVarialbe[pp][nod->subsequence[pp]]);
                }
              
                int wIndex0;
                if (termToVariableS.count(blT) > 0) {
                    wIndex0 = termToVariableS[blT];
                }
                else {
                    bilinearTS.push_back(blT);
                    termToVariableS[blT] = bilinearTS.size() - 1;
                    wIndex0 = bilinearTS.size() - 1;
                    
                }
           
                vector<int> re = { wIndex0 };

                for (auto & ch : nod->children) {
                    vector<int> blTc;
                    for (auto &pp : allTeamPlayers) {
                        blTc.push_back(sequenceToVarialbe[pp][ch->subsequence[pp]]);
                    }
                    int wIndex;
                    if (termToVariableS.count(blTc) > 0) {
                        wIndex = termToVariableS[blTc];

                    }
                    else {
                      
                        bilinearTS.push_back(blTc);
                      
                        termToVariableS[blTc] = bilinearTS.size() - 1;
                        wIndex = bilinearTS.size() - 1;
                        for (int p = 0; p < allTeamPlayers.size(); p++) {
                            bool isFinished = true;
                            for (int pp = 0; pp < allTeamPlayers.size(); pp++) {
                                if (allTeamPlayers[pp] != allTeamPlayers[p]) {
                                    if (ch->subsequence[pp] != "/") {
                                        isFinished = false;
                                    }
                                }
                            }
                            if (isFinished) {
                                termToSeq[wIndex] = { allTeamPlayers[p],blTc[p] };
                            }
                        }
                    }
                    re.push_back(wIndex);
                }
                relations.insert(re);
                    
            }
        }


    }
    
 
    GRBVar **w = new GRBVar*[multilinearterms.size()];
    w[0] =  new GRBVar[bilinearTS.size()];
 
    for(int i = 0; i < bilinearTS.size(); i++){
        w[0][i] = modelEQ.addVar(0.0, 1.0, 0.0, GRB_CONTINUOUS);
    }
    for(int index  = 1; index < multilinearterms.size(); index++){
        w[index] = new GRBVar[bilinearT[index].size()];
        for(int i = 0; i < bilinearT[index].size(); i++){
            w[index][i] = modelEQ.addVar(0.0, 1.0, 0.0, GRB_CONTINUOUS);
        }
        
    }
    
    for (auto &re : relations) {
        GRBLinExpr constraints;
        constraints += w[0][re[0]];
        for (int i = 1; i < re.size(); i++) {
            constraints -= w[0][re[i]];
        }
        modelEQ.addConstr(constraints==0);
    }

    for (auto &k : termToSeq) {
        GRBLinExpr constraints;
        constraints += w[0][k.first];
 
        
        constraints -= rSQ[k.second[0]][k.second[1]];
 
        modelEQ.addConstr(constraints == 0);
    }

    vector<int> blTcc;
    for (int p = 0; p < allTeamPlayers.size(); p++) {
        blTcc.push_back(sequenceToVarialbe[allTeamPlayers[p]]["/"]);
    }
    modelEQ.addConstr(w[0][termToVariableS[blTcc]]  == 1);
    
 
    relations.clear();
    
    
  
    GRBVar *V = new GRBVar[tree.information_sets[player].size()+1];
    std::map<string, vector<shared_ptr<Node> > >::iterator  it0 = tree.information_sets[player].begin();
    for (int i = 0; i < tree.information_sets[player].size(); i++) {
        string seq = it0->first;
       // V[i].setName(seq.c_str());
        it0++;
         
        V[i] = modelEQ.addVar(minU, maxU, 0.0, GRB_CONTINUOUS,seq);
        

    }
    V[tree.information_sets[player].size()] = modelEQ.addVar(minU, maxU, 0.0, GRB_CONTINUOUS);
  

    int seqIndexPlayer = 0;
    for (auto& seq : tree.sequencesAll[player]) {
        
        GRBLinExpr   constraints;
        
        std::map<string, vector<shared_ptr<Node> > >::iterator itInf;
         
        if (seq == "/") {
            
            constraints += V[tree.information_sets[player].size()];
            
        }
        else {
 
            string inf = seq;
            inf.pop_back();
            itInf = tree.information_sets[player].find(inf);

            
            constraints += V[distance(tree.information_sets[player].begin(), itInf)];
             
        }
         
        std::map<string, std::set<string>>::iterator itSQ;
        itSQ = tree.sequences[player].find(seq);
        if (itSQ != tree.sequences[player].end()) {
            for (auto& inf : itSQ->second) {
                itInf = tree.information_sets[player].find(inf);
                constraints -= V[distance(tree.information_sets[player].begin(), itInf)];
            }
        }
        
        for (SpMat::InnerIterator it(payoffMatrix,seqIndexPlayer); it; ++it){
             
            constraints -= w[0][it.row()] * it.value();
        }
        seqIndexPlayer++;
        
  
        modelEQ.addConstr(constraints <= 0);
        
    }

    
    for(int bli = 0 ; bli < variableToTerm[variableToTerm.size()-1].size(); bli++){
       
        GRBQuadExpr constraint;
        constraint += w[variableToTerm.size()-1][bli];
        
        constraint -= rSQ[blTermPlayer[variableToTerm.size()-1][0]][variableToTerm[variableToTerm.size()-1][bli][0]]*rSQ[blTermPlayer[variableToTerm.size()-1][1]][variableToTerm[variableToTerm.size()-1][bli][1]];
    
        modelEQ.addQConstr(constraint == 0);
 
        
    }
    
    for(int index  = 0; index < variableToTerm.size()-1; index++){
        for(int bli = 0 ; bli < variableToTerm[index].size(); bli++){
            GRBQuadExpr constraint;
            constraint += w[index][bli];
           
            constraint -= rSQ[blTermPlayer[index][0]][variableToTerm[index][bli][0]]*w[index+1][variableToTerm[index][bli][1]];
             
            modelEQ.addQConstr(constraint == 0);
 
        }
    }
    
    
    std::cout << "minU: " << minU << "\t maxU \t" << maxU << " difference: " << maxU - minU << std::endl;
    
    std::cout << "minU: " << chanceMinU << "\t maxU \t" << chanceMaxU << " difference: " << chanceMaxU - chanceMinU << std::endl;
    
    
    
    GRBLinExpr obj;
    obj += V[tree.information_sets[player].size()];
    modelEQ.setObjective(obj, GRB_MAXIMIZE);
    
    
  
    
    try{
        
 
        modelEQ.set(GRB_IntParam_NonConvex, 2);
 
        modelEQ.optimize();

 
        end = std::chrono::system_clock::now();
        std::chrono::duration<double> elapsed_seconds = end - start;
 
        cout << "Obj: " << modelEQ.get(GRB_DoubleAttr_ObjVal)<<"\t time \t"<<elapsed_seconds.count()<< endl;
    } catch(GRBException e) {
      cout << "Error code = " << e.getErrorCode() << endl;
      cout << e.getMessage() << endl;
    } catch(...) {
      cout << "Exception during optimization" << endl;
    }
    delete[] rSQ;
        
}

}

int main(int   argc, char *argv[])
{
 
    
    r5::TMEinEFGMatrix();
 
    return 0;
}
