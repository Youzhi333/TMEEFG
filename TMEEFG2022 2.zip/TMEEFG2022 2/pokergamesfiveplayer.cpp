#include "pokergamesfiveplayer.hpp"

namespace r5{
	//int playerNumber = 4;
string leduc_format(int player, vector<Card> holecards, vector<Card> board, string bet_history);
float kuhn_eval(vector<Card> hc, vector<Card> board)
{
    return hc[0].rank;
}
GameRules half_street_kuhn_rules(int playerNumber, int advPlayer, int rankN)
{
    int players = playerNumber;
	int adversaryPlayer = advPlayer;
	vector<Card> deck;
	if (rankN == 3) {
		deck = { Card(13,1),Card(12,1),Card(11,1) };//,Card(10,1), Card(9,1) ,Card(8,1),Card(7,1) ,Card(6,1) ,Card(9,1),Card(8,1),Card(7,1)

	}
	if (rankN == 4) {
		deck = { Card(13,1),Card(12,1),Card(11,1),Card(10,1) };//, Card(9,1) ,Card(8,1),Card(7,1) ,Card(6,1) ,Card(9,1),Card(8,1),Card(7,1)

	}
	if (rankN == 5) {
		deck = { Card(13,1),Card(12,1),Card(11,1),Card(10,1) , Card(9,1) };//
	}
	if (rankN == 6) {
		deck = { Card(13,1),Card(12,1),Card(11,1),Card(10,1) , Card(9,1) ,Card(8,1) };//
	}
	if (rankN == 7) {
		deck = { Card(13,1),Card(12,1),Card(11,1),Card(10,1), Card(9,1) ,Card(8,1),Card(7,1) };//,Card(6,1) ,Card(9,1),Card(8,1),Card(7,1)

	}
	if (rankN == 8) {
		deck = { Card(13,1),Card(12,1),Card(11,1),Card(10,1), Card(9,1) ,Card(8,1),Card(7,1) ,Card(6,1) };//,Card(9,1),Card(8,1),Card(7,1)

	}
	if (rankN == 9) {
		deck = { Card(13,1),Card(12,1),Card(11,1),Card(10,1) , Card(9,1) ,Card(8,1),Card(7,1) ,Card(6,1),Card(5,1), };//,Card(9,1),Card(8,1),Card(7,1)

	}
	if (rankN == 10) {
		deck = { Card(13,1),Card(12,1),Card(11,1),Card(10,1) , Card(9,1) ,Card(8,1),Card(7,1) ,Card(6,1),Card(5,1),  Card(4,1) };//,Card(9,1),Card(8,1),Card(7,1)

	}
	if (rankN == 11) {
		deck = { Card(13,1),Card(12,1),Card(11,1),Card(10,1) , Card(9,1) ,Card(8,1),Card(7,1) ,Card(6,1),Card(5,1),  Card(4,1),Card(3,1) };//,Card(9,1),Card(8,1),Card(7,1)

	}
	if (rankN == 12) {
		deck = { Card(13,1),Card(12,1),Card(11,1),Card(10,1) , Card(9,1) ,Card(8,1),Card(7,1) ,Card(6,1),Card(5,1),  Card(4,1),Card(3,1),Card(2,1) };//,Card(9,1),Card(8,1),Card(7,1)

	}
	if (rankN == 13) {
		deck = { Card(14,1),Card(13,1),Card(12,1),Card(11,1),Card(10,1) , Card(9,1) ,Card(8,1),Card(7,1) ,Card(6,1),Card(5,1),  Card(4,1),Card(3,1),Card(2,1) };//,Card(9,1),Card(8,1),Card(7,1)

	}
    int ante = 1;
    vector<int> blinds;

    //RoundInfo(holecards,boardcards,betsize,maxbets)
	vector<RoundInfo> rounds;
    if (playerNumber == 2) {
        rounds = { RoundInfo(1,0,1,{1,1}) };
    }
	if (playerNumber == 3) {
		rounds = { RoundInfo(1,0,1,{1,0,0}) };
	}
	if (playerNumber == 4) {
		rounds = { RoundInfo(1,0,1,{1,1,0,0}) };
	}
	if (playerNumber == 5) {
		rounds = { RoundInfo(1,0,1,{1,1,0,0,0}) };
	}
	if (playerNumber == 6) {
		rounds = { RoundInfo(1,0,1,{1,1,1,1,0,0}) };
	}
    return GameRules(players, adversaryPlayer, rankN, deck, rounds, ante, blinds, kuhn_eval, leduc_format);
}
GameTree half_street_kuhn_gametree(int playerNumber, int advPlayer, int rankN)
{
    GameRules rules = half_street_kuhn_rules(playerNumber, advPlayer, rankN);
    GameTree tree(rules);
    tree.build();
    return tree;
}
PublicTree half_street_kuhn_publictree(int playerNumber, int advPlayer, int rankN)
{
    GameRules rules = half_street_kuhn_rules(playerNumber, advPlayer, rankN);
    PublicTree tree(rules);
    tree.build();
    return tree;
}
//GameRules kuhn_rules()
//{
//    int players = 3;
//    vector<Card> deck = {Card(13,1),Card(12,1),Card(11,1),Card(10,1)};
//    int ante = 1;
//    vector<int> blinds;
//    vector<RoundInfo> rounds = {RoundInfo(1,0,1,{1,1,1})};
//    return GameRules(players, deck, rounds, ante, blinds, kuhn_eval, leduc_format); 
//}
GameRules kuhn_rules(int playerNumber, int advPlayer, int rankN)
{
	int players = playerNumber;
	int adversaryPlayer = advPlayer;
	vector<Card> deck;
	if (rankN == 3) {
		deck = { Card(13,1),Card(12,1),Card(11,1)  };//, Card(9,1) ,Card(8,1),Card(7,1) ,Card(6,1) ,Card(9,1),Card(8,1),Card(7,1)

	}
	if (rankN == 4) {
		deck = { Card(13,1),Card(12,1),Card(11,1),Card(10,1)};//, Card(9,1) ,Card(8,1),Card(7,1) ,Card(6,1) ,Card(9,1),Card(8,1),Card(7,1)

	}
	if (rankN == 5) {
		deck = { Card(13,1),Card(12,1),Card(11,1),Card(10,1) , Card(9,1)};//
	}
	if (rankN == 6) {
		deck = { Card(13,1),Card(12,1),Card(11,1),Card(10,1) , Card(9,1) ,Card(8,1)};//
	}
	if (rankN == 7) {
		deck = { Card(13,1),Card(12,1),Card(11,1),Card(10,1), Card(9,1) ,Card(8,1),Card(7,1)  };//,Card(6,1) ,Card(9,1),Card(8,1),Card(7,1)

	}
	if (rankN == 8) {
		deck = { Card(13,1),Card(12,1),Card(11,1),Card(10,1), Card(9,1) ,Card(8,1),Card(7,1) ,Card(6,1)  };//,Card(9,1),Card(8,1),Card(7,1)

	}
	if (rankN == 9) {
		deck = { Card(13,1),Card(12,1),Card(11,1),Card(10,1) , Card(9,1) ,Card(8,1),Card(7,1) ,Card(6,1),Card(5,1), };//,Card(9,1),Card(8,1),Card(7,1)

	}
	if (rankN == 10) {
		deck = { Card(13,1),Card(12,1),Card(11,1),Card(10,1) , Card(9,1) ,Card(8,1),Card(7,1) ,Card(6,1),Card(5,1),  Card(4,1) };//,Card(9,1),Card(8,1),Card(7,1)

	}
	if (rankN == 11) {
		deck = { Card(13,1),Card(12,1),Card(11,1),Card(10,1) , Card(9,1) ,Card(8,1),Card(7,1) ,Card(6,1),Card(5,1),  Card(4,1),Card(3,1) };//,Card(9,1),Card(8,1),Card(7,1)

	}
	if (rankN == 12) {
		deck = { Card(13,1),Card(12,1),Card(11,1),Card(10,1) , Card(9,1) ,Card(8,1),Card(7,1) ,Card(6,1),Card(5,1),  Card(4,1),Card(3,1),Card(2,1) };//,Card(9,1),Card(8,1),Card(7,1)

	}
	if (rankN == 13) {
		deck = { Card(14,1),Card(13,1),Card(12,1),Card(11,1),Card(10,1) , Card(9,1) ,Card(8,1),Card(7,1) ,Card(6,1),Card(5,1),  Card(4,1),Card(3,1),Card(2,1) };//,Card(9,1),Card(8,1),Card(7,1)

	}
	int ante = 1;
	vector<int> blinds;
	vector<RoundInfo> rounds;
	if (playerNumber == 2) {
		rounds = { RoundInfo(1,0,1,{1,1}) };
	}
	if (playerNumber == 3) {
		rounds = { RoundInfo(1,0,1,{1,1,1}) };
	}
	if (playerNumber == 4) {
		rounds = { RoundInfo(1,0,1,{1,1,1,1}) };
	}
	if (playerNumber == 5) {
		rounds = { RoundInfo(1,0,1,{1,1,1,1,1}) };
	}
	if (playerNumber == 6) {
		rounds = { RoundInfo(1,0,1,{1,1,1,1,1,1}) };
	}
	if (playerNumber == 7) {
		rounds = { RoundInfo(1,0,1,{1,1,1,1,1,1,1}) };
	}
	if (playerNumber == 8) {
		rounds = { RoundInfo(1,0,1,{1,1,1,1,1,1,1,1}) };
	}
	if (playerNumber == 9) {
		rounds = { RoundInfo(1,0,1,{1,1,1,1,1,1,1,1,1}) };
	}
	if (playerNumber == 10) {
		rounds = { RoundInfo(1,0,1,{1,1,1,1,1,1,1,1,1,1}) };
	}
	//vector<RoundInfo> rounds = { RoundInfo(1,0,1,{1,1,1,1,1}) };
	return GameRules(players, adversaryPlayer, rankN, deck, rounds, ante, blinds, kuhn_eval, leduc_format);
}
GameTree kuhn_gametree(int playerNumber,   int advPlayer, int rankN)
{
    GameRules rules = kuhn_rules( playerNumber, advPlayer, rankN);
    GameTree tree(rules);
	//std::cout << "  1 " << std::endl;
    tree.build();
	//std::cout << "  2 " << std::endl;
    return tree;
}
PublicTree kuhn_publictree(int playerNumber, int advPlayer, int cardN)
{
    GameRules rules = kuhn_rules(playerNumber, advPlayer, cardN);
    PublicTree tree(rules);
    tree.build();
    return tree;
}
string leduc_format(int player, vector<Card> holecards, vector<Card> board, string bet_history)
{
    string cards = holecards[0].RANK_TO_STRING[holecards[0].rank];
    if(board.size() > 0)
        cards += board[0].RANK_TO_STRING[board[0].rank];
    return string(cards + ":" + bet_history+":");
}
float leduc_eval(vector<Card> hc, vector<Card> board)
{
    vector<Card> hand = hc + board;
    if(hand[0].rank == hand[1].rank)
        return 15*14+hand[0].rank;
    return std::max(hand[0].rank, hand[1].rank) * 14 + std::min(hand[0].rank, hand[1].rank);
}

//float leduc_eval(vector<Card> hc, vector<Card> board)
//{
//	vector<Card> hand = hc + board;
//	if (hand[0].rank == hand[1].rank && hand[1].rank == hand[2].rank)
//		return 16*15 * 14 + hand[0].rank;
//	if (hand[0].rank == hand[1].rank)
//		return   15 * 14 + hand[0].rank;
//	if (hand[2].rank == hand[1].rank)
//		return   15 * 14 + hand[1].rank;
//	if (hand[0].rank == hand[2].rank)
//		return   15 * 14 + hand[0].rank;
//	return std::max(std::max(hand[0].rank, hand[1].rank),  hand[2].rank) * 14 + std::min(std::min(hand[0].rank, hand[1].rank), hand[2].rank);
//}

//GameRules leduc_rules()
//{
//    int players = 3;
//	vector<Card> deck = { Card(13,1),Card(13,2),Card(12,1),Card(12,2), Card(11,1),Card(11,2), Card(10, 1), Card(10, 2)};
//    int ante = 1;
//    vector<int> blinds;
//    vector<RoundInfo> rounds = {RoundInfo(1,0,2,{2,2,2}),RoundInfo(0,1,4,{2,2,2})};
//    return GameRules(players, deck, rounds, ante, blinds, leduc_eval, leduc_format);
//}
GameRules leduc_rules2(int playerNumber, int advPlayer, int rankN)
{
	int players = playerNumber;
	int adversaryPlayer = advPlayer;
	vector<Card> deck;
	if (rankN == 3) {
		deck = { Card(13,1),Card(13,2),Card(12,1),Card(12,2), Card(11,1),Card(11,2) };//, Card(10, 1), Card(10, 2) ,Card(9, 1), Card(9, 2), Card(8, 1), Card(8, 2), Card(7, 1), Card(7, 2) };//, Card(10, 1), Card(10, 2), Card(13,3), Card(12,3), Card(11,3), Card{10,3} };
	}
	if (rankN == 4) {
		deck = { Card(13,1),Card(13,2),Card(12,1),Card(12,2), Card(11,1),Card(11,2) , Card(10, 1), Card(10, 2) };// ,Card(9, 1), Card(9, 2), Card(8, 1), Card(8, 2), Card(7, 1), Card(7, 2) };//, Card(10, 1), Card(10, 2), Card(13,3), Card(12,3), Card(11,3), Card{10,3} };
	}	
	if (rankN == 5) {
		deck = { Card(13,1),Card(13,2),Card(12,1),Card(12,2), Card(11,1),Card(11,2) , Card(10, 1), Card(10, 2)  ,Card(9, 1), Card(9, 2)};//, Card(8, 1), Card(8, 2), Card(7, 1), Card(7, 2) };//, Card(10, 1), Card(10, 2), Card(13,3), Card(12,3), Card(11,3), Card{10,3} };
	}
	if (rankN == 6) {
		deck = { Card(13,1),Card(13,2),Card(12,1),Card(12,2), Card(11,1),Card(11,2) , Card(10, 1), Card(10, 2)  ,Card(9, 1), Card(9, 2) , Card(8, 1), Card(8, 2)};//, Card(7, 1), Card(7, 2) };//, Card(10, 1), Card(10, 2), Card(13,3), Card(12,3), Card(11,3), Card{10,3} };
	}
	if (rankN == 7) {
		deck = { Card(13,1),Card(13,2),Card(12,1),Card(12,2), Card(11,1),Card(11,2) , Card(10, 1), Card(10, 2)  ,Card(9, 1), Card(9, 2) , Card(8, 1), Card(8, 2) , Card(7, 1), Card(7, 2) };//, Card(10, 1), Card(10, 2), Card(13,3), Card(12,3), Card(11,3), Card{10,3} };
	}
	if (rankN == 8) {
		deck = { Card(13,1),Card(13,2),Card(12,1),Card(12,2), Card(11,1),Card(11,2) , Card(10, 1), Card(10, 2)  ,Card(9, 1), Card(9, 2) , Card(8, 1), Card(8, 2) , Card(7, 1), Card(7, 2), Card(6, 1), Card(6, 2) };//, Card(10, 1), Card(10, 2), Card(13,3), Card(12,3), Card(11,3), Card{10,3} };
	}
	if (rankN == 9) {
		deck = { Card(13,1),Card(13,2),Card(12,1),Card(12,2), Card(11,1),Card(11,2) , Card(10, 1), Card(10, 2)  ,Card(9, 1), Card(9, 2) , Card(8, 1), Card(8, 2) , Card(7, 1), Card(7, 2), Card(6, 1), Card(6, 2), Card(5, 1), Card(5, 2) };//, Card(10, 1), Card(10, 2), Card(13,3), Card(12,3), Card(11,3), Card{10,3} };
	}
	if (rankN == 10) {
		deck = { Card(13,1),Card(13,2),Card(12,1),Card(12,2), Card(11,1),Card(11,2) , Card(10, 1), Card(10, 2)  ,Card(9, 1), Card(9, 2) , Card(8, 1), Card(8, 2) , Card(7, 1), Card(7, 2), Card(6, 1), Card(6, 2), Card(5, 1), Card(5, 2), Card(4, 1), Card(4, 2) };//, Card(10, 1), Card(10, 2), Card(13,3), Card(12,3), Card(11,3), Card{10,3} };
	}
	int ante = 1;
	vector<int> blinds;
	vector<RoundInfo> rounds;
	if (playerNumber == 3) {
		rounds = { RoundInfo(1,0,2,{1,1,1}),RoundInfo(0,1,4,{1,1,1}) };
	}
	if (playerNumber == 4) {
		rounds = { RoundInfo(1,0,2,{1,1,1,1}),RoundInfo(0,1,4,{1,1,1,1}) };
	}
	if (playerNumber == 5) {
		rounds = { RoundInfo(1,0,2,{1,1,1,1,1}),RoundInfo(0,1,4,{1,1,1,1,1}) };
	}
	if (playerNumber == 6) {
		rounds = { RoundInfo(1,0,2,{1,1,1,1,1}),RoundInfo(0,1,4,{1,1,1,1,1,1}) };
	}
	if (playerNumber == 7) {
		rounds = { RoundInfo(1,0,2,{1,1,1,1,1}),RoundInfo(0,1,4,{1,1,1,1,1,1,1}) };
	}
	if (playerNumber == 8) {
		rounds = { RoundInfo(1,0,2,{1,1,1,1,1}),RoundInfo(0,1,4,{1,1,1,1,1,1,1,1}) };
	}
	//vector<RoundInfo> rounds = { RoundInfo(1,0,2,{1,1,1,1,1}),RoundInfo(0,1,4,{1,1,1,1,1}) };
	return GameRules(players, adversaryPlayer, rankN, deck, rounds, ante, blinds, leduc_eval, leduc_format);
}
GameRules leduc_rules(int playerNumber, int advPlayer, int rankN)
{
	int players = playerNumber;
	int adversaryPlayer = advPlayer;
	vector<Card> deck;
	if (rankN == 20) {
		deck = { Card(13,1),  Card(12,1),Card(11,1), Card(10,1), Card(9,1) };
	}
	if (rankN == 2) {
		deck ={Card(13,1),Card(13,2),Card(13,3),Card(12,1),Card(12,2), Card(12,3)};// { Card(13,1),Card(13,2), Card(12,1), Card(12,2)    };//, Card(10, 1), Card(10, 2) ,Card(9, 1), Card(9, 2), Card(8, 1), Card(8, 2), Card(7, 1), Card(7, 2) };//, Card(10, 1), Card(10, 2), Card(13,3), Card(12,3), Card(11,3), Card{10,3} };
	}
	//if (rankN == 3) {
    //    deck = {Card(13,1),Card(13,2), Card(13,3),  Card(12,1), Card(12,2), Card(12,3),Card(11,1),Card(11,2),Card(11,3)};//{ Card(13,1),Card(13,2) ,  Card(12,1), Card(12,2)  ,Card(11,1),Card(11,2) };//{Card(13,1),Card(13,2), Card(13,3),  Card(12,1), Card(12,2), Card(12,3),Card(11,1),Card(11,2),Card(11,3)};//{ Card(13,1),Card(13,2) ,  Card(12,1), Card(12,2)  ,Card(11,1),Card(11,2), Card(10, 1), Card(10, 2) };//   };//, Card(10, 2) ,Card(9, 1), Card(9, 2), Card(8, 1), Card(8, 2), Card(7, 1), Card(7, 2) };//, Card(10, 1), Card(10, 2), Card(13,3), Card(12,3), Card(11,3), Card{10,3} };
	//}
    if (rankN == 3) {
        deck = { Card(13,1),Card(13,2) ,  Card(12,1), Card(12,2)  ,Card(11,1),Card(11,2) };//{Card(13,1),Card(13,2),Card(13,3),Card(12,1),Card(12,2), Card(12,3),Card(11,1),Card(11,2), Card(11,3) };//{ Card(13,1),Card(13,2) ,  Card(12,1), Card(12,2)  ,Card(11,1),Card(11,2) };//{Card(13,1),Card(13,2), Card(13,3),  Card(12,1), Card(12,2), Card(12,3),Card(11,1),Card(11,2),Card(11,3)};//{ Card(13,1),Card(13,2) ,  Card(12,1), Card(12,2)  ,Card(11,1),Card(11,2), Card(10, 1), Card(10, 2) };//   };//, Card(10, 2) ,Card(9, 1), Card(9, 2), Card(8, 1), Card(8, 2), Card(7, 1), Card(7, 2) };//, Card(10, 1), Card(10, 2), Card(13,3), Card(12,3), Card(11,3), Card{10,3} };
    }
	//if (rankN == 4) {
	//	deck = { Card(13,1),Card(13,2),Card(13,3),Card(12,1),Card(12,2), Card(12,3),Card(11,1),Card(11,2), Card(11,3) , Card(10, 1), Card(10, 2), Card(10, 3) };// ,Card(9, 1), Card(9, 2), Card(8, 1), Card(8, 2), Card(7, 1), Card(7, 2) };//, Card(10, 1), Card(10, 2), Card(13,3), Card(12,3), Card(11,3), Card{10,3} };
	//}
//    if (rankN == 5) {
//        deck = { Card(13,1),Card(13,2),Card(13,3),Card(12,1),Card(12,2), Card(12,3),Card(11,1),Card(11,2), Card(11,3) , Card(10, 1), Card(10, 2), Card(10, 3)  ,Card(9, 1), Card(9, 2), Card(9, 3) };//, Card(8, 1), Card(8, 2), Card(7, 1), Card(7, 2) };//, Card(10, 1), Card(10, 2), Card(13,3), Card(12,3), Card(11,3), Card{10,3} };
//    }
    if (rankN == 4) {
        deck = { Card(13,1),Card(13,2),Card(12,1),Card(12,2),Card(11,1),Card(11,2), Card(10, 1), Card(10, 2) };// ,Card(9, 1), Card(9, 2), Card(8, 1), Card(8, 2), Card(7, 1), Card(7, 2) };//, Card(10, 1), Card(10, 2), Card(13,3), Card(12,3), Card(11,3), Card{10,3} };
    }
//	if (rankN == 5) {
//		deck = { Card(13,1),Card(13,2),Card(12,1),Card(12,2),Card(11,1),Card(11,2), Card(10, 1), Card(10, 2)  ,Card(9, 1), Card(9, 2) };//, Card(8, 1), Card(8, 2), Card(7, 1), Card(7, 2) };//, Card(10, 1), Card(10, 2), Card(13,3), Card(12,3), Card(11,3), Card{10,3} };
//	}
    if (rankN == 5) {
        deck = { Card(13,1), Card(12,1), Card(11,1),  Card(10, 1),  Card(9, 1) };//, Card(8, 1), Card(8, 2), Card(7, 1), Card(7, 2) };//, Card(10, 1), Card(10, 2), Card(13,3), Card(12,3), Card(11,3), Card{10,3} };
    }
    if (rankN == 6) {
        deck = { Card(13,1), Card(12,1), Card(11,1),  Card(10, 1),  Card(9, 1),  Card(8, 1)  };//, Card(8, 1), Card(8, 2), Card(7, 1), Card(7, 2) };//, Card(10, 1), Card(10, 2), Card(13,3), Card(12,3), Card(11,3), Card{10,3} };
    }
//	if (rankN == 6) {
//		deck = { Card(13,1),Card(13,2),Card(13,3),Card(12,1),Card(12,2), Card(12,3),Card(11,1),Card(11,2), Card(11,3) , Card(10, 1), Card(10, 2), Card(10, 3)  ,Card(9, 1), Card(9, 2), Card(9, 3) , Card(8, 1), Card(8, 2), Card(8, 3) };//, Card(7, 1), Card(7, 2) };//, Card(10, 1), Card(10, 2), Card(13,3), Card(12,3), Card(11,3), Card{10,3} };
//	}
	if (rankN == 7) {
		deck = { Card(13,1),Card(13,2), Card(12,1),Card(12,2),  Card(11,1),Card(11,2),   Card(10, 1), Card(10, 2)   ,Card(9, 1), Card(9, 2),  Card(8, 1), Card(8, 2),  Card(7, 1), Card(7, 2)  };
		//deck = { Card(13,1),Card(13,2),Card(13,3),Card(12,1),Card(12,2), Card(12,3),Card(11,1),Card(11,2), Card(11,3) , Card(10, 1), Card(10, 2), Card(10, 3)  ,Card(9, 1), Card(9, 2), Card(9, 3) , Card(8, 1), Card(8, 2), Card(8, 3), Card(7, 1), Card(7, 2), Card(7, 3) };//, Card(10, 1), Card(10, 2), Card(13,3), Card(12,3), Card(11,3), Card{10,3} };
	}
	if (rankN == 8) {
		deck = { Card(13,1),Card(13,2),Card(13,3),Card(12,1),Card(12,2), Card(12,3),Card(11,1),Card(11,2), Card(11,3) , Card(10, 1), Card(10, 2), Card(10, 3)  ,Card(9, 1), Card(9, 2), Card(9, 3) , Card(8, 1), Card(8, 2), Card(8, 3), Card(7, 1), Card(7, 2), Card(7, 3), Card(6, 1), Card(6, 2), Card(6, 3) };//, Card(10, 1), Card(10, 2), Card(13,3), Card(12,3), Card(11,3), Card{10,3} };
	}
	if (rankN == 9) {
		deck = { Card(13,1),Card(13,2),Card(13,3),Card(12,1),Card(12,2), Card(12,3),Card(11,1),Card(11,2), Card(11,3) , Card(10, 1), Card(10, 2), Card(10, 3)  ,Card(9, 1), Card(9, 2), Card(9, 3) , Card(8, 1), Card(8, 2), Card(8, 3), Card(7, 1), Card(7, 2), Card(7, 3), Card(6, 1), Card(6, 2), Card(6, 3), Card(5, 1), Card(5, 2), Card(5, 3) };//, Card(10, 1), Card(10, 2), Card(13,3), Card(12,3), Card(11,3), Card{10,3} };
	}
	if (rankN == 10) {
		deck = { Card(13,1),Card(13,2),Card(13,3),Card(12,1),Card(12,2), Card(12,3),Card(11,1),Card(11,2), Card(11,3) , Card(10, 1), Card(10, 2), Card(10, 3)  ,Card(9, 1), Card(9, 2), Card(9, 3) , Card(8, 1), Card(8, 2), Card(8, 3), Card(7, 1), Card(7, 2), Card(7, 3), Card(6, 1), Card(6, 2), Card(6, 3), Card(5, 1), Card(5, 2), Card(5, 3), Card(4, 1), Card(4, 2), Card(4, 3) };//, Card(10, 1), Card(10, 2), Card(13,3), Card(12,3), Card(11,3), Card{10,3} };
	}
	if (rankN == 12) {
		deck = { Card(13,1),Card(13,2),Card(13,3),Card(12,1),Card(12,2), Card(12,3),Card(11,1),Card(11,2), Card(11,3) , Card(10, 1), Card(10, 2), Card(10, 3)  ,Card(9, 1), Card(9, 2), Card(9, 3) , Card(8, 1), Card(8, 2), Card(8, 3), Card(7, 1), Card(7, 2), Card(7, 3), Card(6, 1), Card(6, 2), Card(6, 3), Card(5, 1), Card(5, 2), Card(5, 3), Card(4, 1), Card(4, 2), Card(4, 3),Card(3, 1), Card(3, 2), Card(3, 3), Card(2, 1), Card(2, 2), Card(2, 3) };//, Card(10, 1), Card(10, 2), Card(13,3), Card(12,3), Card(11,3), Card{10,3} };
	}
	if (rankN == 13) {
		deck = { Card(14,1),Card(14,2),Card(14,3), Card(13,1),Card(13,2),Card(13,3),Card(12,1),Card(12,2), Card(12,3),Card(11,1),Card(11,2), Card(11,3) , Card(10, 1), Card(10, 2), Card(10, 3)  ,Card(9, 1), Card(9, 2), Card(9, 3) , Card(8, 1), Card(8, 2), Card(8, 3), Card(7, 1), Card(7, 2), Card(7, 3), Card(6, 1), Card(6, 2), Card(6, 3), Card(5, 1), Card(5, 2), Card(5, 3), Card(4, 1), Card(4, 2), Card(4, 3),Card(3, 1), Card(3, 2), Card(3, 3), Card(2, 1), Card(2, 2), Card(2, 3) };//, Card(10, 1), Card(10, 2), Card(13,3), Card(12,3), Card(11,3), Card{10,3} };
	}
	int ante = 1;
	vector<int> blinds;
	vector<RoundInfo> rounds;
	if (playerNumber == 2) {
        rounds = {RoundInfo(1,0,2,{2,2}),RoundInfo(0,1,4,{2,2})};//{ RoundInfo(1,0,2,{1,1}),RoundInfo(0,1,4,{1,1}) }; //rounds = { RoundInfo(1,0,2,{2,1,1}),RoundInfo(0,1,4,{2,1,1}),RoundInfo(0,1,4,{1,1,1}) };
	}
	if (playerNumber == 3) {
		rounds = { RoundInfo(1,0,2,{1,1,1}),RoundInfo(0,1,4,{1,1,1}) }; //rounds = { RoundInfo(1,0,2,{2,1,1}),RoundInfo(0,1,4,{2,1,1}),RoundInfo(0,1,4,{1,1,1}) };
	}
	if (playerNumber == 4) {
		rounds = { RoundInfo(1,0,2,{1,1,1,1}),RoundInfo(0,1,4,{1,1,1,1}) };
	}
	if (playerNumber == 5) {
		rounds = { RoundInfo(1,0,2,{0,0,0,0,1}),RoundInfo(0,1,4,{0,0,0,0,1}) };
	}
	//vector<RoundInfo> rounds = { RoundInfo(1,0,2,{1,1,1,1,1}),RoundInfo(0,1,4,{1,1,1,1,1}) };
	return GameRules(players, adversaryPlayer, rankN, deck, rounds, ante, blinds, leduc_eval, leduc_format);
}

GameTree leduc_gametree(int playerNumber, int advPlayer, int rankN)
{
    GameRules rules = leduc_rules(playerNumber, advPlayer, rankN);
    GameTree tree(rules);
    tree.build();
    return tree;
}
PublicTree leduc_publictree(int playerNumber, int advPlayer, int rankN)
{
    GameRules rules = leduc_rules(playerNumber, advPlayer, rankN);
    PublicTree tree(rules);
    tree.build();
    return tree;
}
string royal_format(int player, vector<Card> holecards, vector<Card> board, string bet_history)
{
    string cards = holecards[0].RANK_TO_STRING[holecards[0].rank];
    for(int i=0; i<board.size(); i++)
	{
        cards += board[i].RANK_TO_STRING[board[i].rank];
        if(board[i].suit == holecards[0].suit)
            cards += 's';
        else
            cards += 'o';
	}
    return string(cards + ":" + bet_history+":");
}
float royal_eval(vector<Card> hc, vector<Card> board)
{
    vector<Card> hand = hc + board;
    // Flush
    if(hand[0].suit == hand[1].suit && hand[0].suit == hand[2].suit)
        return 10000 + hc[0].rank;
    // Straight
	vector<int> ranks;
	std::transform(hand.begin(),hand.end(),ranks.begin(),[](Card c){return c.rank;});
    if(std::find(ranks.begin(),ranks.end(),Card::RANK_QUEEN)!=ranks.end() && std::find(ranks.begin(),ranks.end(),Card::RANK_KING)!= ranks.end())
	{
        if(std::find(ranks.begin(),ranks.end(),Card::RANK_ACE) != ranks.end())
            return 1000 + Card::RANK_ACE;
        if(std::find(ranks.begin(),ranks.end(),Card::RANK_JACK) != ranks.end())
            return 1000 + Card::RANK_JACK;
	}
    // Holecard used in a pair
    if(hand[0].rank == hand[1].rank || hand[0].rank == hand[2].rank)
        return 100+hand[0].rank;
    return hand[0].rank;
}
GameRules royal_rules(int playerNumber, int advPlayer, int rankN)
{
	int players = playerNumber;
	int adversaryPlayer = advPlayer;
    //int players = 2;
	vector<Card> deck;
	if (rankN == 3) {
		deck = { Card(14,1),Card(14,2),Card(14,3),Card(13,1),Card(13,2),Card(13,3),Card(12,1),Card(12,2),Card(12,3)  };
	}
	if (rankN == 4) {
		deck = { Card(14,1),Card(14,2),Card(14,3),Card(13,1),Card(13,2),Card(13,3),Card(12,1),Card(12,2),Card(12,3),Card(11,1),Card(11,2),Card(11,3) };
	}
	if (rankN == 5) {
		deck = { Card(14,1),Card(14,2),Card(14,3),Card(13,1),Card(13,2),Card(13,3),Card(12,1),Card(12,2),Card(12,3),Card(11,1),Card(11,2),Card(11,3),Card(10,1),Card(10,2),Card(10,3) };
	}
    int ante = 1;
    vector<int> blinds;
	vector<RoundInfo> rounds;
	if (playerNumber == 3) {
		RoundInfo preflop = RoundInfo(1, 0, 2, { 2,2,2 });
		RoundInfo flop = RoundInfo(0, 1, 4, { 2,2,2 });
		RoundInfo turn = RoundInfo(0, 1, 4, { 2,2,2 });
		rounds = { preflop,flop,turn };
	}
	if (playerNumber == 4) {
		RoundInfo preflop = RoundInfo(1, 0, 2, { 2,2,2,2 });
		RoundInfo flop = RoundInfo(0, 1, 4, { 2,2,2,2 });
		RoundInfo turn = RoundInfo(0, 1, 4, { 2,2,2,2 });
		rounds = { preflop,flop,turn };
	}
    return GameRules(players, adversaryPlayer, rankN,  deck, rounds, ante, blinds, royal_eval, royal_format);
}
GameTree royal_gametree(int playerNumber, int advPlayer, int rankN)
{
    GameRules rules = royal_rules( playerNumber,  advPlayer,  rankN);
    GameTree tree(rules);
    tree.build();
    return tree;
}
PublicTree royal_publictree(int playerNumber, int advPlayer, int rankN)
{
    GameRules rules = royal_rules( playerNumber,  advPlayer,  rankN);
    PublicTree tree(rules);
    tree.build();
    return tree;
}

}

